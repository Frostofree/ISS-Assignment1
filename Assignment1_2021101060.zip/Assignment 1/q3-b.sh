#!/bin/bash
cat Test.txt | wc -l ##Test.txt is the input file