#!/bin/bash
cat Test.txt |tr ' ' '\n' | sort | uniq -c | awk '{print $2 " - " $1}' > out.txt