The Zip Folder 'Assignment 1' Contains 5 Folders and one README.txt.
Each folder contains Either a singular question, or multiple subquestions broken down into multiple shell scripts.

Q1:
The Following Question has two subparts, solved in two files q1a, q1b
q1a:
After Changing The directory to the folder in which q1a.sh is present,run the following commands

  $ chmod +x q1a.sh
  $ ./q1a.sh
The script takes a File named quotes.txt and gives the output in another file out.txt
q1b:
After Changing The directory to the folder in which q1b.sh is present,run the following commands

  $ chmod +x q1b.sh
  $ ./q1b.sh
The script takes a File named quotes.txt and gives the output in another file out2.txt


Q2:
The Following Question is solved using q2.sh
After Changing The directory to the folder in which q1b.sh is present,run the following commands
  $ chmod +x q2.sh
  $ ./q2.sh
The script takes in a file quotes.txt and outputs a file speech.txt


Q3:
The Following Question has two subparts, solved in two files q3a, q3b,q3c,q3d and q3e
Questions q3a-q3d Print output onto the terminal and hence can be compiled as follows
  $ chmod +x <shell_File>
  $ ./<shell_File>
NOTE:- EACH OF THE FOLLOWING QUESTIONS TAKES IN A FILE named test.txt IN THE BASH SCRIPT. 
Question q3e takes in a file named test.txt and outputs the result into out.txt


Q4:
The Following Question is solved using q4.sh
After Changing The directory to the folder in which q4.sh is present,run the following commands
  $ chmod +x q4.sh
  $ ./q4.sh
The script takes in a file in.txt, which contains a list of comma seperated values(csv), and the shell script outputs them in ascending order on the terminal.


Q5:
The Following Question has three subparts, solved in two files q5a, q5b and q5c.
Each of the following Questions takes in a string from the terminal, and then outputs the appropriate answer onto the terminal
   $ chmod +x <shell_File>
   $ ./<shell_File>
   $ <input_here>

This concludes Assignment 1.
Github Repo link.


