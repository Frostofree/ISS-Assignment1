read Word;
echo $Word | rev