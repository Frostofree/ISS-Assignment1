#!/bin/bash
cat Test.txt | wc
