cat Test.txt | wc
