#!/bin/bash
awk 'NF && !seen[$0]++' quotes.txt