#!/bin/bash
read Word;
echo $Word | rev
revstr=`echo $Word | rev`
echo $revstr | tr 'a-z A-Z' 'b-z A-Z'
strlen=${#Word}
revlen=$((strlen/2))
for((i=$((revlen-1)); i>=0; i--))
do 
    revst=$revst${Word:$i:1}
done
echo -n ${revst}
echo -n ${Word:$revlen}
